package com.app.mvc.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.app.mvc.DTO.MatrimonyDTO;
@Repository
public class MatrimonyDAO {
	
	@Autowired
	private SessionFactory sf;
	
	
	public void register(MatrimonyDTO dto) {
		Session sess=sf.openSession();
		sess.save(dto);
		sess.beginTransaction().commit();
	}
	
	public List<MatrimonyDTO> loadAllData() {
		/*Session sess=sf.openSession();
		Criteria criteria =  sess.createCriteria(MatrimonyDTO.class);
		List<MatrimonyDTO> dtos = criteria.list();
		return dtos;*/
		
		return sf.openSession().createCriteria(MatrimonyDTO.class).list();
	}
	
	
	
	//update a record
	public void update(MatrimonyDTO dto) {
		Session sess=sf.openSession();
		sess.update(dto);
		sess.beginTransaction().commit();
	}
	
	
	public void deleteRecord(int slNo) {
		Session sess=sf.openSession();
		MatrimonyDTO matrimony=sess.load(MatrimonyDTO.class, slNo);
		sess.delete(matrimony);
		sess.beginTransaction().commit();
	}
	
	
	
	
	
}
