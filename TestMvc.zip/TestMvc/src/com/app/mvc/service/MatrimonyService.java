package com.app.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.app.mvc.DAO.MatrimonyDAO;
import com.app.mvc.DTO.MatrimonyDTO;
@Service
public class MatrimonyService {
	
	@Autowired
	private MatrimonyDAO dao;
	
	public void register(MatrimonyDTO dto) {
		dao.register(dto);
	}
	public List<MatrimonyDTO> loadFromDAO() {
		/*List<MatrimonyDTO>matrimonyDAOs = dao.loadAllData();
		return matrimonyDAOs;*/
		//Above line replacement for code optimization
		return dao.loadAllData();
	}
	public void update(MatrimonyDTO dto) {
		dao.update(dto);
	}
	
	public void delete(int SlNo) {
		dao.deleteRecord(SlNo);
	}
}
