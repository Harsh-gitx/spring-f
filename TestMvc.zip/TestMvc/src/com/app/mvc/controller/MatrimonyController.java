package com.app.mvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.app.mvc.DTO.MatrimonyDTO;
import com.app.mvc.service.MatrimonyService;

@Controller
@RequestMapping("/")
public class MatrimonyController {
	
	@Autowired
	private MatrimonyService service;
	
	public MatrimonyController() {
		System.out.println("entering constructor");
	}
	//methods for Each Request
	//register
	@RequestMapping(value="/register.do",method=RequestMethod.POST)
	public String register(@ModelAttribute MatrimonyDTO dto) {
		service.register(dto);
		
		
		return "views/success.html"; //When String is return type
	}
	
	//login
	@RequestMapping(value="/loadAllData.do",method=RequestMethod.GET)
	public ModelAndView loadFromService() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("LoadMatrimony");
		
		List<MatrimonyDTO> dtos = service.loadFromDAO();
		modelAndView.addObject("users", dtos);
		
		return modelAndView;
		
	}
	
	@RequestMapping(value="/update.do")
	public ModelAndView update(@ModelAttribute MatrimonyDTO dto) {
		service.update(dto);
		return null;
	}
	
	@RequestMapping(value="/delete.do")
	public void delete(@RequestParam("slNo") int slNo) {
		System.out.println(slNo);
		service.delete(slNo);
	}
	
}
